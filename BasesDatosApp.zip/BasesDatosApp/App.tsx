import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import Inicio from './src/screens/Inicio';
import SQLite from './src/screens/SQLite';
import Firebase from './src/screens/Firebase';
import MongoDB from './src/screens/MongoDB';
import { temas, IdTema } from './src/data/temas';

export default function App() {
  const [actual, setActual] = useState<IdTema | null>(null);
  const volver = () => setActual(null);

  const tema = temas.find((t) => t.id === actual);

  let pantalla = <Inicio onElegir={setActual} />;
  if (tema) {
    if (tema.id === 'sqlite') pantalla = <SQLite tema={tema} onVolver={volver} />;
    if (tema.id === 'firebase') pantalla = <Firebase tema={tema} onVolver={volver} />;
    if (tema.id === 'mongodb') pantalla = <MongoDB tema={tema} onVolver={volver} />;
  }

  return (
    <>
      {pantalla}
      <StatusBar style="light" />
    </>
  );
}
