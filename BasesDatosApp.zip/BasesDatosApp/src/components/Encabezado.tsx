import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { colores } from '../theme';

interface Props {
  titulo: string;
  color: string;
  onVolver: () => void;
}

const Encabezado = ({ titulo, color, onVolver }: Props) => (
  <View style={[styles.barra, { borderBottomColor: color }]}>
    <FontAwesome name="arrow-left" style={styles.icono} onPress={onVolver} />
    <Text style={[styles.titulo, { color }]}>{titulo}</Text>
    <View style={styles.espacio} />
  </View>
);

export default Encabezado;

const styles = StyleSheet.create({
  barra: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 45,
    paddingBottom: 12,
    paddingHorizontal: 18,
    backgroundColor: colores.superficie,
    borderBottomWidth: 3,
  },
  icono: { fontSize: 22, color: colores.texto },
  titulo: { fontSize: 20, fontWeight: 'bold', letterSpacing: 1 },
  espacio: { width: 22 },
});
