import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';
import Encabezado from './Encabezado';
import { Tema } from '../data/temas';
import { colores } from '../theme';

interface Props {
  tema: Tema;
  onVolver: () => void;
  children: React.ReactNode;
}

/** Plantilla comun: encabezado, imagen, descripcion y el ejercicio de cada tema (children). */
const PantallaTema = ({ tema, onVolver, children }: Props) => (
  <View style={styles.fondo}>
    <Encabezado titulo={tema.titulo.toUpperCase()} color={tema.color} onVolver={onVolver} />
    <ScrollView contentContainerStyle={styles.contenido}>
      <Image source={tema.imagen} style={styles.imagen} />
      <Text style={styles.descripcion}>{tema.descripcion}</Text>
      <View style={[styles.panel, { borderColor: tema.color }]}>{children}</View>
    </ScrollView>
  </View>
);

export default PantallaTema;

export const estilosEjercicio = StyleSheet.create({
  etiqueta: { color: colores.texto, fontWeight: 'bold', marginBottom: 6 },
  input: {
    backgroundColor: colores.fondo,
    borderWidth: 1,
    borderColor: colores.borde,
    color: colores.texto,
    padding: 10,
    borderRadius: 10,
    marginBottom: 12,
  },
  fila: { flexDirection: 'row', marginTop: 4 },
  resultado: {
    backgroundColor: colores.fondo,
    borderRadius: 10,
    padding: 12,
    marginTop: 14,
  },
  textoResultado: { color: colores.texto },
});

const styles = StyleSheet.create({
  fondo: { flex: 1, backgroundColor: colores.fondo },
  contenido: { padding: 16, paddingBottom: 40 },
  imagen: { width: '100%', height: 190, borderRadius: 16, marginBottom: 14 },
  descripcion: { color: colores.textoSuave, fontSize: 16, lineHeight: 23, marginBottom: 16 },
  panel: {
    backgroundColor: colores.superficie,
    borderWidth: 1,
    borderRadius: 16,
    padding: 14,
  },
});
