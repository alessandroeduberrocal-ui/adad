import React from 'react';
import { View, Text } from 'react-native';
import { estilosEjercicio as e } from './PantallaTema';

const Resultado = ({ texto }: { texto: string }) => (
  <View style={e.resultado}>
    <Text style={e.etiqueta}>Resultado:</Text>
    <Text style={e.textoResultado}>{texto}</Text>
  </View>
);

export default Resultado;
