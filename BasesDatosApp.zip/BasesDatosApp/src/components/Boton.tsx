import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colores } from '../theme';

interface Props {
  texto: string;
  onPress: () => void;
  color?: string;
  colorTexto?: string;
}

const Boton = ({ texto, onPress, color = colores.primario, colorTexto = '#000' }: Props) => (
  <TouchableOpacity style={[styles.boton, { backgroundColor: color }]} onPress={onPress}>
    <Text style={[styles.texto, { color: colorTexto }]}>{texto}</Text>
  </TouchableOpacity>
);

export default Boton;

const styles = StyleSheet.create({
  boton: {
    flex: 1,
    paddingVertical: 13,
    borderRadius: 24,
    marginHorizontal: 4,
  },
  texto: {
    textAlign: 'center',
    fontWeight: 'bold',
  },
});
