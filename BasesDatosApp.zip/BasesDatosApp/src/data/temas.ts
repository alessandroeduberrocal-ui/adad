import { ImageSourcePropType } from 'react-native';

export type IdTema = 'sqlite' | 'firebase' | 'mongodb';

export interface Tema {
  id: IdTema;
  titulo: string;
  descripcion: string;
  color: string;
  imagen: ImageSourcePropType;
}

export const imagenPortada: ImageSourcePropType = require('../../assets/basesdatos.png');

export const introduccion =
  'Las bases de datos para aplicaciones moviles pueden guardar la informacion de forma local en el dispositivo o en la nube para sincronizarla entre usuarios y dispositivos.';

export const temas: Tema[] = [
  {
    id: 'sqlite',
    titulo: 'SQLite',
    descripcion:
      'Motor de base de datos relacional ligero que se guarda en un solo archivo dentro del dispositivo. Funciona sin conexion y viene integrado en Android e iOS.',
    color: '#42a5f5',
    imagen: require('../../assets/sqlite.png'),
  },
  {
    id: 'firebase',
    titulo: 'Firebase',
    descripcion:
      'Plataforma de Google que ofrece base de datos en la nube con sincronizacion en tiempo real, autenticacion y hosting, ideal para apps que necesitan datos compartidos.',
    color: '#ffb300',
    imagen: require('../../assets/firebase.png'),
  },
  {
    id: 'mongodb',
    titulo: 'MongoDB',
    descripcion:
      'Base de datos NoSQL orientada a documentos que guarda la informacion en formato similar a JSON. Es flexible y escala facilmente con muchos datos.',
    color: '#66bb6a',
    imagen: require('../../assets/mongodb.png'),
  },
];
