export const colores = {
  fondo: '#12121c',
  superficie: '#1e1e2e',
  borde: '#33334d',
  texto: '#f2f2f7',
  textoSuave: '#a8a8c0',
  primario: '#00bfa5',
  peligro: '#ff5252',
};
