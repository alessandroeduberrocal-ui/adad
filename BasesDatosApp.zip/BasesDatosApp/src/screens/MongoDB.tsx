import React, { useState } from 'react';
import { Text, TextInput, View } from 'react-native';
import PantallaTema, { estilosEjercicio as e } from '../components/PantallaTema';
import Boton from '../components/Boton';
import Resultado from '../components/Resultado';
import { Tema } from '../data/temas';
import { colores } from '../theme';

// Ejercicio: contar palabras y caracteres de un texto
const MongoDB = ({ tema, onVolver }: { tema: Tema; onVolver: () => void }) => {
  const [texto, setTexto] = useState('');
  const [resultado, setResultado] = useState('-');

  const contar = () => {
    const limpio = texto.trim();
    if (limpio === '') {
      alert('Escribe un texto');
      return;
    }
    const palabras = limpio.split(/\s+/).length;
    setResultado(`Palabras: ${palabras} | Caracteres: ${texto.length} | Sin espacios: ${texto.replace(/\s/g, '').length}`);
  };

  const limpiar = () => {
    setTexto('');
    setResultado('-');
  };

  return (
    <PantallaTema tema={tema} onVolver={onVolver}>
      <Text style={e.etiqueta}>Escribe un texto</Text>
      <TextInput
        style={[e.input, { height: 90, textAlignVertical: 'top' }]}
        placeholder="Ej: MongoDB guarda documentos"
        placeholderTextColor={colores.textoSuave}
        multiline
        value={texto}
        onChangeText={setTexto}
      />
      <View style={e.fila}>
        <Boton texto="Contar" onPress={contar} color={tema.color} />
        <Boton texto="Limpiar" onPress={limpiar} color={colores.peligro} colorTexto="#fff" />
      </View>
      <Resultado texto={resultado} />
    </PantallaTema>
  );
};

export default MongoDB;
