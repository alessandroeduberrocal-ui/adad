import React, { useState } from 'react';
import { Text, TextInput, View } from 'react-native';
import PantallaTema, { estilosEjercicio as e } from '../components/PantallaTema';
import Boton from '../components/Boton';
import Resultado from '../components/Resultado';
import { Tema } from '../data/temas';
import { colores } from '../theme';

// Ejercicio: calcular el precio final aplicando un porcentaje de descuento
const Firebase = ({ tema, onVolver }: { tema: Tema; onVolver: () => void }) => {
  const [precio, setPrecio] = useState('');
  const [descuento, setDescuento] = useState('');
  const [resultado, setResultado] = useState('-');

  const calcular = () => {
    if (precio.trim() === '' || descuento.trim() === '') {
      alert('Completa el precio y el descuento');
      return;
    }
    const p = Number(precio);
    const d = Number(descuento);
    if (isNaN(p) || isNaN(d) || p < 0) {
      alert('Ingresa valores numericos validos');
      return;
    }
    if (d < 0 || d > 100) {
      alert('El descuento debe estar entre 0 y 100');
      return;
    }
    const ahorro = (p * d) / 100;
    setResultado(`Ahorras S/ ${ahorro.toFixed(2)}. Precio final: S/ ${(p - ahorro).toFixed(2)}`);
  };

  const limpiar = () => {
    setPrecio('');
    setDescuento('');
    setResultado('-');
  };

  return (
    <PantallaTema tema={tema} onVolver={onVolver}>
      <Text style={e.etiqueta}>Precio del plan (S/)</Text>
      <TextInput
        style={e.input}
        placeholder="Ej: 120"
        placeholderTextColor={colores.textoSuave}
        keyboardType="numeric"
        value={precio}
        onChangeText={setPrecio}
      />
      <Text style={e.etiqueta}>Descuento (%)</Text>
      <TextInput
        style={e.input}
        placeholder="Ej: 15"
        placeholderTextColor={colores.textoSuave}
        keyboardType="numeric"
        value={descuento}
        onChangeText={setDescuento}
      />
      <View style={e.fila}>
        <Boton texto="Calcular" onPress={calcular} color={tema.color} />
        <Boton texto="Limpiar" onPress={limpiar} color={colores.peligro} colorTexto="#fff" />
      </View>
      <Resultado texto={resultado} />
    </PantallaTema>
  );
};

export default Firebase;
