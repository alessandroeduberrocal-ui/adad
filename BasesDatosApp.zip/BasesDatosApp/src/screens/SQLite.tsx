import React, { useState } from 'react';
import { Text, TextInput } from 'react-native';
import PantallaTema, { estilosEjercicio as e } from '../components/PantallaTema';
import Boton from '../components/Boton';
import Resultado from '../components/Resultado';
import { View } from 'react-native';
import { Tema } from '../data/temas';
import { colores } from '../theme';

// Ejercicio: convertir grados Celsius a Fahrenheit y Kelvin
const SQLite = ({ tema, onVolver }: { tema: Tema; onVolver: () => void }) => {
  const [celsius, setCelsius] = useState('');
  const [resultado, setResultado] = useState('-');

  const convertir = () => {
    if (celsius.trim() === '') {
      alert('Ingresa los grados Celsius');
      return;
    }
    const c = Number(celsius);
    if (isNaN(c)) {
      alert('Ingresa solo numeros');
      return;
    }
    const f = (c * 9) / 5 + 32;
    const k = c + 273.15;
    setResultado(`${c} °C = ${f.toFixed(2)} °F = ${k.toFixed(2)} K`);
  };

  const limpiar = () => {
    setCelsius('');
    setResultado('-');
  };

  return (
    <PantallaTema tema={tema} onVolver={onVolver}>
      <Text style={e.etiqueta}>Temperatura en °C</Text>
      <TextInput
        style={e.input}
        placeholder="Ej: 25"
        placeholderTextColor={colores.textoSuave}
        keyboardType="numeric"
        value={celsius}
        onChangeText={setCelsius}
      />
      <View style={e.fila}>
        <Boton texto="Convertir" onPress={convertir} color={tema.color} />
        <Boton texto="Limpiar" onPress={limpiar} color={colores.peligro} colorTexto="#fff" />
      </View>
      <Resultado texto={resultado} />
    </PantallaTema>
  );
};

export default SQLite;
