import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { imagenPortada, introduccion, temas, IdTema } from '../data/temas';
import { colores } from '../theme';

const Inicio = ({ onElegir }: { onElegir: (id: IdTema) => void }) => (
  <ScrollView style={styles.fondo} contentContainerStyle={styles.contenido}>
    <Text style={styles.titulo}>Bases de Datos para Apps Moviles</Text>
    <Image source={imagenPortada} style={styles.portada} />
    <Text style={styles.parrafo}>{introduccion}</Text>

    <Text style={styles.subtitulo}>Elige una tecnologia</Text>
    <View style={styles.grilla}>
      {temas.map((t) => (
        <TouchableOpacity
          key={t.id}
          style={[styles.tarjeta, { borderColor: t.color }]}
          onPress={() => onElegir(t.id)}
        >
          <Image source={t.imagen} style={styles.miniatura} />
          <Text style={[styles.nombre, { color: t.color }]}>{t.titulo}</Text>
        </TouchableOpacity>
      ))}
    </View>
  </ScrollView>
);

export default Inicio;

const styles = StyleSheet.create({
  fondo: { flex: 1, backgroundColor: colores.fondo },
  contenido: { padding: 18, paddingTop: 55, paddingBottom: 40 },
  titulo: {
    color: colores.texto,
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 14,
  },
  portada: { width: '100%', height: 200, borderRadius: 18, marginBottom: 14 },
  parrafo: { color: colores.textoSuave, fontSize: 16, lineHeight: 23, marginBottom: 22 },
  subtitulo: { color: colores.texto, fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  grilla: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  tarjeta: {
    width: '48%',
    backgroundColor: colores.superficie,
    borderWidth: 2,
    borderRadius: 16,
    padding: 8,
    marginBottom: 14,
  },
  miniatura: { width: '100%', height: 90, borderRadius: 10 },
  nombre: { textAlign: 'center', fontWeight: 'bold', fontSize: 16, marginTop: 8 },
});
